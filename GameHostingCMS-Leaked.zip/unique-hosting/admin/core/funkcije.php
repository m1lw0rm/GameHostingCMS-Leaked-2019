<?php 
	 $ip = $_SERVER['REMOTE_ADDR'];

	
	

	

?>