<script>

var randomScalingFactor = function(){ return Math.round(Math.random()*1000)};
	
	var lineChartData = {
			labels : ["January","February","March","April","May","June","July"],
			datasets : [
				{
					label: "My First dataset",
					fillColor : "rgba(220,220,220,0.2)",
					strokeColor : "rgba(220,220,220,1)",
					pointColor : "rgba(220,220,220,1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(220,220,220,1)",
					data : [randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor()]
				},
				{
					label: "My Second dataset",
					fillColor : "rgba(48, 164, 255, 0.2)",
					strokeColor : "rgba(48, 164, 255, 1)",
					pointColor : "rgba(48, 164, 255, 1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(48, 164, 255, 1)",
					data : [randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor()]
				}
			]

		}
		
	var barChartData = {
			labels : ["Ukupno poseta","Danas","Juce","Pos. 7 dana"],
			datasets : [
				{
					fillColor : "rgba(220,220,220,0.5)",
					strokeColor : "rgba(220,220,220,0.8)",
					highlightFill: "rgba(220,220,220,0.75)",
					highlightStroke: "rgba(220,220,220,1)",
					data : [
					
					<?php 
						
						$datum = date('d.m.Y');
						
						$ukupno_poseta = mysqli_num_rows(mysqli_query($con,"SELECT id FROM posete"));
						$danas_poseta = mysqli_num_rows(mysqli_query($con,"SELECT id FROM posete WHERE `datum`='$datum'"));
						
						
						echo "$ukupno_poseta,$danas_poseta";
						
							
					?>
					
					]
				}
			]
	
		}

	var pieData = [
				{
					value: 300,
					color:"#30a5ff",
					highlight: "#62b9fb",
					label: "Blue"
				},
				{
					value: 50,
					color: "#ffb53e",
					highlight: "#fac878",
					label: "Orange"
				},
				{
					value: 100,
					color: "#1ebfae",
					highlight: "#3cdfce",
					label: "Teal"
				},
				{
					value: 120,
					color: "#f9243f",
					highlight: "#f6495f",
					label: "Red"
				}

			];
		
	var doughnutData = [
					{
					<?php 
						
						$cs = mysqli_num_rows(mysqli_query($con,"SELECT id FROM narudzbine WHERE igra='cs'"));
						$samp = mysqli_num_rows(mysqli_query($con,"SELECT id FROM narudzbine WHERE igra='samp'"));
						$ts3 =  mysqli_num_rows(mysqli_query($con,"SELECT id FROM narudzbine WHERE igra='ts3'"));
						$csgo = mysqli_num_rows(mysqli_query($con,"SELECT id FROM narudzbine WHERE igra='csgo'"));
																						
						
					?>
						
						value: <?php echo $cs; ?>,
						color:"#30a5ff",
						highlight: "#62b9fb",
						label: "CS 1.6"
					},
					{
						value: <?php echo $samp; ?>,
						color: "#FF3030",
						highlight: "#FB5D5D",
						label: "SAMP"
					},
					{
						value: <?php echo $ts3; ?>,
						color: "#FF30BB",
						highlight: "#FC61C9",
						label: "TS3"
					},
					{
						value: <?php echo $csgo; ?>,
						color: "#CC30FF",
						highlight: "#D55DFC",
						label: "CSGO"
					}
				];

window.onload = function(){
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
		responsive: true
	});
	var chart2 = document.getElementById("bar-chart").getContext("2d");
	window.myBar = new Chart(chart2).Bar(barChartData, {
		responsive : true
	});
	
	
	var chart3 = document.getElementById("doughnut-chart").getContext("2d");
	window.myDoughnut = new Chart(chart3).Doughnut(doughnutData, {responsive : true
	});
	
	
	var chart4 = document.getElementById("pie-chart").getContext("2d");
	window.myPie = new Chart(chart4).Pie(pieData, {responsive : true
	});
	
};

</script>


	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<!-- UGASENO <script src="js/chart-data.js"></script> -->
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/bootstrap-table.js"></script>	
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
