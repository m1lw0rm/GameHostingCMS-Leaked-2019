<?php /* Smarty version Smarty-3.0.7, created on 2018-01-07 00:33:26
         compiled from "template/head.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20672428985a515cc6c13fc5-95674303%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce4f18f149392d8c9d12a5f884b821e50c3e0cfd' => 
    array (
      0 => 'template/head.tpl',
      1 => 1515245622,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20672428985a515cc6c13fc5-95674303',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Uniq Hosting</title>
<link rel="stylesheet" type="text/css" href="template/css/style.css" media="all" />
<script src="template/js/jquery-1.6.2.min.js" type="text/javascript"></script>
<script src="template/js/gpanel.js" type="text/javascript"></script>
<script src="template/js/jquery.alerts.js" type="text/javascript"></script>
</head>
<body>