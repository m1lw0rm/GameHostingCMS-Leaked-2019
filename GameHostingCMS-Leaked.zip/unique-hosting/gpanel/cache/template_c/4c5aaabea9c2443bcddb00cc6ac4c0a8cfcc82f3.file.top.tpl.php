<?php /* Smarty version Smarty-3.0.7, created on 2018-01-07 00:40:49
         compiled from "template/top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20452675835a515e819452a6-65096461%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4c5aaabea9c2443bcddb00cc6ac4c0a8cfcc82f3' => 
    array (
      0 => 'template/top.tpl',
      1 => 1503364022,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20452675835a515e819452a6-65096461',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="main">
<div id="logo"><a href="index.php"><img src="template/images/logoplushoster.png" border="0" /></a></div>

<br /><br />

<!-- SOU Hosting - Navigacija -->
			<div id="navigacijaa">
				<ul id="navigacijaa-razmak">
					<li><a class="aktivno" href="index2.php">POCETNA</a></li>
					<li><a href="/gpanel/main.php">GAME PANEL</a></li>
					<li><a href="/gpanel/cs-server.php">NARUCI</a></li>
					<li><a href="web-usluge.php">WEB HOSTING</a></li>
					<li><a href="vps.php">VPS</a></li>
					<li><a href="kontakt.php">KONTAKT</a></li>
				</ul>
			</div>


<div id="navgacija_bg">
<div id="navigacija">
<ul>
<li><a href="main.php" id="menuitem" class="menu_item">OBAVESTENJA</a></li>
<li><a href="main.php?page=serveri" id="menuitem" class="menu_item">SERVERI</a></li>
<li><a href="main.php?page=podrska" id="menuitem" class="menu_item">PODRSKA</a></li>
<li><a href="main.php?page=profil" id="menuitem" class="menu_item">KORISNICKI PANEL</a></li>
<li><a href="logout.php" id="menuitem" class="menu_item">ODJAVI SE</a></li>
</ul>
</div>