<?php /* Smarty version Smarty-3.0.7, created on 2018-01-07 00:33:26
         compiled from "template/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13941782595a515cc6cce6c2-77574388%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '93eba9ec02e7a31cffc73eb24f851ab6d425dd9c' => 
    array (
      0 => 'template/footer.tpl',
      1 => 1440858642,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13941782595a515cc6cce6c2-77574388',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
</body>
</html>