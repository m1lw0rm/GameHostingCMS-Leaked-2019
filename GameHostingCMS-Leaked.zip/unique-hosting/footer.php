<br />
<div class="footer">
	Copyright &copy 2018 <?php echo $site_title; ?> 
	<br />
	Sva prava zadrzana!
</div>
<br />
	<!-- script references -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>